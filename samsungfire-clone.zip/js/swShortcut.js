const swShortcut = new Swiper(".sw-shortcut", {
 centeredSlides: false,
 slidesPerView: "auto",
});
