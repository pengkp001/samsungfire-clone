# 삼성화재 클론 코딩

- https://www.samsungfire.com/

## 반응형 break point

- max-width: 1219px | 1220px
- min-width: 1220px
- max-width: 767px | 768px
- min-width: 768px
- max-width: 585px | 586px
- min-width: 586px
